typedef enum{
    e_success,
    e_failure
}status;

typedef struct song
{
    char* file_name;
    FILE* file_pointer; 
    FILE* copy_pointer;
    char* edit_name;
    char edit_type;
    int len;
    int new_or_not;
    char* new_file;
    char* tag;   
}mp3;

status Type_Operation(char* argv,mp3 *MP3);

//view
status validate(mp3 *MP3);
status checkID3(FILE* fptr);
status check_version(FILE* fptr);
status BIG_to_LITTLE(int num);
status open_mp3_file(mp3 *MP3);
status skip_header(FILE *fptr);
status printdetails(mp3 *MP3);
status view(mp3 *MP3);

//edit
status open_copyfile(mp3 *MP3);
status select_tag(mp3 *MP3);
status change(mp3 *MP3);
status tag_edit(mp3 *MP3);
status copy_remaining(mp3 *MP3);
status copy_to_src(mp3 *MP3);
status edit(mp3 *MP3);
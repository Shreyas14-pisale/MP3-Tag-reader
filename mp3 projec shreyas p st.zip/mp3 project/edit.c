#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include"mp3.h"

status select_tag(mp3 *MP3){
  char select = MP3->edit_type;
  switch(select){
    case 't': MP3->tag="TIT2"; break;
    case 'a': MP3->tag="TPE1"; break;
    case 'A': MP3->tag="TALB";break;
    case 'y': MP3->tag="TYER";break;
    case 'm': MP3->tag="TCON";break;
    case 'c': MP3->tag="COMM";break;
    default:
    printf("ERROR: Invalid option"); 
    return e_failure;
  }
  printf("Selected tag:%s\n",MP3->tag);
  return e_success;
}

status change(mp3 *MP3){
   MP3->new_file = "copy.mp3";
}

status open_copyfile(mp3 *MP3)
{ 
     MP3->copy_pointer=fopen(MP3->new_file,"w+");
     MP3->file_pointer=fopen(MP3->file_name,"r");
     if(MP3->file_pointer == NULL){
        printf("%s file not found!\n",MP3->file_name);
    }
}

status tag_edit(mp3 *MP3){
  char tag[4];
  while(1){              //running loop till finding the tag to be edited
      fread(tag,1,4,MP3->file_pointer);
      //comparing every 4 bytes
      //if tag is matched
      if(strcmp(tag,MP3->tag)==0){
          //writing the tag name
          fwrite(tag,1,4,MP3->copy_pointer);
          //writing new size
            int len = strlen(MP3->edit_name);//size based on string length
            MP3->len = len;
            len++;                           //incrementing len
            len = BIG_to_LITTLE(len);        //converting little to big;
            fwrite(&len,sizeof(int),1,MP3->copy_pointer);//storing to copy pointer

          //writing new data
          char flag[3];
          fread(flag,1,3,MP3->file_pointer);
                    fwrite(flag,1,3,MP3->copy_pointer);

          //writing new data passed in CLA
          fwrite(MP3->edit_name,1,MP3->len,MP3->copy_pointer);
          printf("\033[32m-----------Edited successfully-----------\n");
          printf("\033[0m \n");
          break;
      }
      //if tag is not found
      else{
          //taking the offset back 3 bytes, because tag name can be shuffled
          fseek(MP3->file_pointer,-3,SEEK_CUR);
          fwrite(tag,1,1,MP3->copy_pointer);//writing the same byte to copy
      }
    }
}

status copy_remaining(mp3 *MP3){

    //skipping the old details of tag in src file
    int size;
    fread(&size,4,1,MP3->file_pointer);
    size--;
    fseek(MP3->file_pointer,size,SEEK_CUR);

    //copying all data till end of file
    int ch;
    while((ch = getc(MP3->file_pointer))!=EOF){
        putc(ch,MP3->copy_pointer);
    }
}

status copy_to_src(mp3 *MP3){
    rewind(MP3->copy_pointer);
    FILE* fptr = fopen(MP3->file_name,"w");    //opening the src file in write mode
    int ch;
    while((ch = getc(MP3->copy_pointer))!=EOF){//writing all data to src file
        putc(ch,fptr);
    }
    fclose(MP3->copy_pointer);                 //closing both the pointers
    fclose(fptr);
    remove("copy.mp3");                       //removing the copy file
}

status edit(mp3 *MP3)
{
    if(validate(MP3)==e_failure){
        return e_failure;
    }
    if(select_tag(MP3)==e_failure){
        return e_failure;
    }
    if(change(MP3)==e_failure){
        return e_failure;
    }
    if(open_copyfile(MP3)==e_failure){
        return e_failure;
    }
    if(tag_edit(MP3)==e_failure){
        return e_failure;
    }
    if(copy_remaining(MP3)==e_failure){
        return e_failure;
    }
    if(copy_to_src(MP3)==e_failure){
            return e_failure;
    }
}


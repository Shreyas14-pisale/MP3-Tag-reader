#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include"mp3.h"

mp3 MP3;

int main(int argc, char* argv[]){

    if(argc<3){
        printf("\n---------------------------Invalid Command Line Arguments------------------------------\n");
        printf("---------------------------------------------------------------------------------------\n");
        printf("ERROR: ./a.out : INVALID ARGUMENTS\n");
        printf("USAGE :\n\tTo view please pass like: ./a.out -v mp3filename\n");
        printf("\tTo edit please pass like: ./a.out -e -t/-a/-A/-m/-y/-c changing_text mp3filename\n");
        printf("\tTo get help pass like : ./a.out --help\n");
        printf("---------------------------------------------------------------------------------------\n\n");

        if(argc != 1)
        Type_Operation(argv[1],&MP3);
        
        return e_failure;
    }
    else if(argc==3){
        
    MP3.file_name = argv[2];                //copying file name to structur
    Type_Operation(argv[1],&MP3);           //checking operation type
    }
     else if(argc == 5){
        
        MP3.file_name = argv[4];        //copying file name to structure
        MP3.edit_type = argv[2][1];     //copying type of tag to add
        MP3.edit_name = argv[3];        
        Type_Operation(argv[1],&MP3);
    }
    else{
        printf("ERROR: Invalid arguments\n");
    }
}
   

   //checking type of operation
status Type_Operation(char* argv,mp3 *MP3){
    //for displaying help menu
    if(strcmp(argv,"--help")==0){
        printf("->HELP MENU");
        printf("\n----------------------HELP MENU------------------------\n");
        printf("1. -v -> to view mp3 file contents\n");
        printf("2. -e -> to edit mp3 file contents\n");
        printf("\t2.1. -t ->to edit song tittle\n");
        printf("\t2.2. -a ->to edit artist name\n");
        printf("\t2.3. -A ->to edit album name\n");
        printf("\t2.4. -y ->to edit year \n");
        printf("\t2.5. -m ->to edit content \n");
        printf("\t2.6. -c ->to edit comment\n");
        printf("\n-----------------------------------------------------\n");
    }
    //for viewing details
    else if(strcmp(argv,"-v")==0){
        if(view(MP3)==e_failure){
            return e_failure;
        }
    }
    //for editing details
    else if(strcmp(argv,"-e")==0){
        if(edit(MP3)==e_failure){
            return e_failure;
        }
    }
    //for invalid arguments
    else{
        printf("ERROR: Invalid arguments\n");
    }
}

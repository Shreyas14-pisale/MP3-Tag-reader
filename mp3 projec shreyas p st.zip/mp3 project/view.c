#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include"mp3.h"


status validate(mp3 *MP3){
    char* str = strchr(MP3->file_name,'.');
    if(str == NULL){
        printf("ERROR: %s is not a .mp3 file\n",MP3->file_name);
        return e_failure;
    }
    else if(strcmp(str,".mp3")!=0){
        printf("ERROR: %s is not a .mp3 file\n",MP3->file_name);
        return e_failure;
    }
}

//checking ID3 exist or not
status checkID3(FILE* fptr){
    char buffer[4];
    fread(buffer,1,3,fptr);
    if(strcmp(buffer,"ID3")){
        printf("ERROR: ID3 tag does not exist\n");
        return e_failure;
    }
}

//checking version is v2 or not
status check_version(FILE* fptr){
    short version=0;
    fread(&version,2,1,fptr);
    if(version!=3){
        printf("ERROR: Not a file of version v2\n");
        return e_failure;
    }
}


//in mp3 file the data is stored in big endian formate, but our system is little endian so converting from big to little
status BIG_to_LITTLE(int num){
    //typecasting num to char pointer to acess each byte
    char* cptr = (char*)&num;
    //swapping first and last byte
    int temp = cptr[0];
    cptr[0] = cptr[3];
    cptr[3]=temp;

    //swapping second and third byte
    temp=cptr[1];
    cptr[1]=cptr[2];
    cptr[2]=temp;

    return num;
}

status open_mp3_file(mp3 *MP3)
{ 
     MP3->file_pointer=fopen(MP3->file_name,"r");
     if(MP3->file_pointer == NULL){
        printf("%s file not found!\n",MP3->file_name);
        return e_failure;
    }
}
status skip_header(FILE* fptr){
    rewind (fptr);
    fseek(fptr,10,SEEK_SET);
}

status printdetails(mp3 *MP3)
{
    printf("---------------------------SELECTED VIEW--------------------------\n");
    printf("------------------------------------------------------------------\n");
    printf("\t\tMP3 TAG READER AND EDITOR FOR ID3v2\n");
    printf("------------------------------------------------------------------\n");
    for(int i=1;i<=6;i++)
    {
    char tag[4];
    fread(tag,1,4,MP3->file_pointer);
    if(strcmp(tag,"TIT2")==0){
        printf("TITle\t:\t");
    }
    else if(strcmp(tag,"TPE1")==0){
        printf("ARTIST\t:\t");
    }
    else if(strcmp(tag,"TALB")==0){
        printf("ALBUM\t:\t");
    }
    else if(strcmp(tag,"TYER")==0){
        printf("YEAR\t:\t");
    }
    else if(strcmp(tag,"TCON")==0){
        printf("MUSIC\t:\t");
    }
    if(strcmp(tag,"COMM")==0){
        printf("COMMENT\t:\t");
    }
    int size;
    fread(&size,4,1,MP3->file_pointer);
    fseek(MP3->file_pointer,3,SEEK_CUR);
    int size1=BIG_to_LITTLE(size);
    char title[size1];
    memset(title,0,size1);
    fread(title,1,size1-1,MP3->file_pointer);
    printf("%s\n",title);
    //printf("%x",BIG_to_LITTLE(size));
 }     
 printf("------------------------------------------------------------------\n");
}
status view(mp3 *MP3)
{
  if(validate(MP3)==e_failure){
        return e_failure;
    }
    if(open_mp3_file(MP3)==e_failure){
        return e_failure;
    }
    if(checkID3(MP3->file_pointer)==e_failure){
        return e_failure;
    }
    if(check_version(MP3->file_pointer)==e_failure){
        return e_failure;
    }
    if(skip_header(MP3->file_pointer)==e_failure){
        return e_failure;
    }
    if(printdetails(MP3)==e_failure){
        return e_failure;
    }
}

